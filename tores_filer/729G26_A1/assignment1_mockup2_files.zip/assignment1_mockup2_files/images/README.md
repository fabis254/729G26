# REAME

Image credits for the images used in assignment 1:

- Li Yang: https://unsplash.com/?photo=_vPCiuXL2HE
- Simon Petrol: https://unsplash.com/?photo=oFpjqLKWAs8
- Marcela Laskoski: https://unsplash.com/?photo=YrtFlrLo2DQ
- Subtlepatterns: http://subtlepatterns.com/greyzz/
